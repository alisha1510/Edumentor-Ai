'use client';

import { useState, useCallback, useRef, useEffect } from 'react';

interface UseVoiceOptions {
  onSpeakStart?: () => void;
  onSpeakEnd?: () => void;
  enabled?: boolean;
}

export function useVoice(options: UseVoiceOptions = {}) {
  const { onSpeakStart, onSpeakEnd, enabled = true } = options;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis;
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, []);

  // Web Speech API fallback
  const speakWithWebSpeech = useCallback((text: string) => {
    if (!synthRef.current) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.85; // Slower for children
    utterance.pitch = 1.2; // Slightly higher pitch
    utterance.volume = 1;

    // Try to find a friendly female voice
    const voices = synthRef.current.getVoices();
    const preferredVoice = voices.find(
      v => v.name.includes('Samantha') || 
           v.name.includes('Google US English') ||
           (v.lang.startsWith('en') && v.name.toLowerCase().includes('female'))
    ) || voices.find(v => v.lang.startsWith('en')) || voices[0];
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
      onSpeakStart?.();
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      onSpeakEnd?.();
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setError('Speech synthesis error');
      onSpeakEnd?.();
    };

    synthRef.current.speak(utterance);
  }, [onSpeakStart, onSpeakEnd]);

  // ElevenLabs TTS with fallback
  const speak = useCallback(async (text: string) => {
    if (!enabled || !text.trim()) return;

    setError(null);
    setIsLoading(true);

    try {
      // Try ElevenLabs API first
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) {
        throw new Error('TTS API unavailable');
      }

      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      if (audioRef.current) {
        audioRef.current.pause();
      }
      
      audioRef.current = new Audio(audioUrl);
      
      audioRef.current.onplay = () => {
        setIsSpeaking(true);
        onSpeakStart?.();
      };
      
      audioRef.current.onended = () => {
        setIsSpeaking(false);
        onSpeakEnd?.();
        URL.revokeObjectURL(audioUrl);
      };
      
      audioRef.current.onerror = () => {
        setIsSpeaking(false);
        onSpeakEnd?.();
        // Fallback to Web Speech API
        speakWithWebSpeech(text);
      };

      setIsLoading(false);
      await audioRef.current.play();
      
    } catch {
      setIsLoading(false);
      // Fallback to Web Speech API
      speakWithWebSpeech(text);
    }
  }, [enabled, onSpeakStart, onSpeakEnd, speakWithWebSpeech]);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    if (synthRef.current) {
      synthRef.current.cancel();
    }
    setIsSpeaking(false);
    onSpeakEnd?.();
  }, [onSpeakEnd]);

  return {
    speak,
    stop,
    isSpeaking,
    isLoading,
    error,
  };
}
