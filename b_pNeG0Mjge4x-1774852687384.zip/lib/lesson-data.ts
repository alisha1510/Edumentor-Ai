export interface LetterData {
  letter: string;
  word: string;
  imageDescription: string;
  sound: string;
}

export interface NumberData {
  number: number;
  word: string;
  objects: string;
}

export interface PhonicsData {
  sound: string;
  words: string[];
  example: string;
}

export interface FirstWordData {
  word: string;
  category: string;
  imageDescription: string;
}

export const ALPHABET_DATA: LetterData[] = [
  { letter: 'A', word: 'Apple', imageDescription: 'red apple', sound: '/æ/' },
  { letter: 'B', word: 'Ball', imageDescription: 'bouncy ball', sound: '/b/' },
  { letter: 'C', word: 'Cat', imageDescription: 'cute cat', sound: '/k/' },
  { letter: 'D', word: 'Dog', imageDescription: 'happy dog', sound: '/d/' },
  { letter: 'E', word: 'Elephant', imageDescription: 'gray elephant', sound: '/ɛ/' },
  { letter: 'F', word: 'Fish', imageDescription: 'orange fish', sound: '/f/' },
  { letter: 'G', word: 'Grapes', imageDescription: 'purple grapes', sound: '/g/' },
  { letter: 'H', word: 'Hat', imageDescription: 'colorful hat', sound: '/h/' },
  { letter: 'I', word: 'Ice cream', imageDescription: 'ice cream cone', sound: '/ɪ/' },
  { letter: 'J', word: 'Juice', imageDescription: 'glass of juice', sound: '/dʒ/' },
  { letter: 'K', word: 'Kite', imageDescription: 'flying kite', sound: '/k/' },
  { letter: 'L', word: 'Lion', imageDescription: 'brave lion', sound: '/l/' },
  { letter: 'M', word: 'Moon', imageDescription: 'crescent moon', sound: '/m/' },
  { letter: 'N', word: 'Nest', imageDescription: 'bird nest', sound: '/n/' },
  { letter: 'O', word: 'Orange', imageDescription: 'orange fruit', sound: '/ɒ/' },
  { letter: 'P', word: 'Penguin', imageDescription: 'cute penguin', sound: '/p/' },
  { letter: 'Q', word: 'Queen', imageDescription: 'royal queen', sound: '/kw/' },
  { letter: 'R', word: 'Rainbow', imageDescription: 'colorful rainbow', sound: '/r/' },
  { letter: 'S', word: 'Sun', imageDescription: 'bright sun', sound: '/s/' },
  { letter: 'T', word: 'Tree', imageDescription: 'green tree', sound: '/t/' },
  { letter: 'U', word: 'Umbrella', imageDescription: 'red umbrella', sound: '/ʌ/' },
  { letter: 'V', word: 'Violin', imageDescription: 'musical violin', sound: '/v/' },
  { letter: 'W', word: 'Watermelon', imageDescription: 'sliced watermelon', sound: '/w/' },
  { letter: 'X', word: 'Xylophone', imageDescription: 'colorful xylophone', sound: '/ks/' },
  { letter: 'Y', word: 'Yo-yo', imageDescription: 'spinning yo-yo', sound: '/j/' },
  { letter: 'Z', word: 'Zebra', imageDescription: 'striped zebra', sound: '/z/' },
];

export const NUMBERS_DATA: NumberData[] = [
  { number: 1, word: 'One', objects: 'star' },
  { number: 2, word: 'Two', objects: 'hearts' },
  { number: 3, word: 'Three', objects: 'balloons' },
  { number: 4, word: 'Four', objects: 'flowers' },
  { number: 5, word: 'Five', objects: 'butterflies' },
  { number: 6, word: 'Six', objects: 'cookies' },
  { number: 7, word: 'Seven', objects: 'clouds' },
  { number: 8, word: 'Eight', objects: 'crayons' },
  { number: 9, word: 'Nine', objects: 'birds' },
  { number: 10, word: 'Ten', objects: 'apples' },
  { number: 11, word: 'Eleven', objects: 'leaves' },
  { number: 12, word: 'Twelve', objects: 'eggs' },
  { number: 13, word: 'Thirteen', objects: 'candies' },
  { number: 14, word: 'Fourteen', objects: 'fish' },
  { number: 15, word: 'Fifteen', objects: 'bubbles' },
  { number: 16, word: 'Sixteen', objects: 'cupcakes' },
  { number: 17, word: 'Seventeen', objects: 'strawberries' },
  { number: 18, word: 'Eighteen', objects: 'pencils' },
  { number: 19, word: 'Nineteen', objects: 'raindrops' },
  { number: 20, word: 'Twenty', objects: 'stars' },
];

export const PHONICS_DATA: PhonicsData[] = [
  { sound: 'at', words: ['cat', 'hat', 'bat', 'mat'], example: 'The cat sat on a mat.' },
  { sound: 'an', words: ['can', 'fan', 'man', 'pan'], example: 'The man has a fan.' },
  { sound: 'ap', words: ['cap', 'map', 'tap', 'nap'], example: 'Take a nap with your cap.' },
  { sound: 'et', words: ['pet', 'wet', 'get', 'set'], example: 'Get your pet!' },
  { sound: 'en', words: ['hen', 'pen', 'ten', 'den'], example: 'Ten hens in the pen.' },
  { sound: 'ig', words: ['pig', 'big', 'dig', 'wig'], example: 'The big pig can dig.' },
  { sound: 'it', words: ['sit', 'hit', 'bit', 'fit'], example: 'Sit and hit the ball.' },
  { sound: 'op', words: ['hop', 'top', 'pop', 'mop'], example: 'Hop to the top!' },
  { sound: 'ot', words: ['hot', 'pot', 'dot', 'got'], example: 'The pot is hot.' },
  { sound: 'ug', words: ['bug', 'hug', 'mug', 'rug'], example: 'Give the bug a hug!' },
  { sound: 'un', words: ['sun', 'fun', 'run', 'bun'], example: 'Run in the sun for fun!' },
  { sound: 'ut', words: ['cut', 'but', 'nut', 'hut'], example: 'Cut the nut in the hut.' },
];

export const FIRST_WORDS_DATA: FirstWordData[] = [
  // Animals
  { word: 'Dog', category: 'Animals', imageDescription: 'friendly dog' },
  { word: 'Cat', category: 'Animals', imageDescription: 'fluffy cat' },
  { word: 'Bird', category: 'Animals', imageDescription: 'singing bird' },
  { word: 'Fish', category: 'Animals', imageDescription: 'swimming fish' },
  { word: 'Bear', category: 'Animals', imageDescription: 'teddy bear' },
  // Food
  { word: 'Apple', category: 'Food', imageDescription: 'red apple' },
  { word: 'Banana', category: 'Food', imageDescription: 'yellow banana' },
  { word: 'Milk', category: 'Food', imageDescription: 'glass of milk' },
  { word: 'Cookie', category: 'Food', imageDescription: 'chocolate cookie' },
  { word: 'Bread', category: 'Food', imageDescription: 'loaf of bread' },
  // Family
  { word: 'Mom', category: 'Family', imageDescription: 'loving mother' },
  { word: 'Dad', category: 'Family', imageDescription: 'caring father' },
  { word: 'Baby', category: 'Family', imageDescription: 'cute baby' },
  { word: 'Home', category: 'Family', imageDescription: 'cozy home' },
  { word: 'Love', category: 'Family', imageDescription: 'heart symbol' },
  // Nature
  { word: 'Sun', category: 'Nature', imageDescription: 'bright sun' },
  { word: 'Moon', category: 'Nature', imageDescription: 'glowing moon' },
  { word: 'Star', category: 'Nature', imageDescription: 'twinkling star' },
  { word: 'Tree', category: 'Nature', imageDescription: 'green tree' },
  { word: 'Flower', category: 'Nature', imageDescription: 'colorful flower' },
];

export const LESSON_MODULES = [
  {
    id: 'alphabet',
    title: 'ABC Adventure',
    description: 'Learn all 26 letters!',
    icon: 'abc',
    color: 'bg-pink-500',
    totalItems: 26,
  },
  {
    id: 'numbers',
    title: 'Number Fun',
    description: 'Count from 1 to 20!',
    icon: '123',
    color: 'bg-blue-500',
    totalItems: 20,
  },
  {
    id: 'phonics',
    title: 'Sound Safari',
    description: 'Match sounds and words!',
    icon: 'sound',
    color: 'bg-green-500',
    totalItems: 12,
  },
  {
    id: 'words',
    title: 'First Words',
    description: 'Learn simple words!',
    icon: 'book',
    color: 'bg-orange-500',
    totalItems: 20,
  },
];
