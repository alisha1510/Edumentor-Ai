export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: string;
}

export interface LessonProgress {
  moduleId: string;
  completedItems: string[];
  quizScores: number[];
  lastAccessed: string;
}

export interface UserProgress {
  name: string;
  totalXP: number;
  currentStreak: number;
  lastActiveDate: string;
  badges: Badge[];
  lessonProgress: Record<string, LessonProgress>;
  settings: {
    soundEnabled: boolean;
    voiceEnabled: boolean;
  };
}

const STORAGE_KEY = 'edumentor-progress';

const DEFAULT_BADGES: Badge[] = [
  {
    id: 'first-lesson',
    name: 'First Steps',
    description: 'Complete your first lesson',
    icon: 'star',
  },
  {
    id: 'alphabet-master',
    name: 'ABC Champion',
    description: 'Learn all 26 letters',
    icon: 'trophy',
  },
  {
    id: 'number-wizard',
    name: 'Number Wizard',
    description: 'Master counting 1-20',
    icon: 'calculator',
  },
  {
    id: 'streak-hero',
    name: 'Streak Hero',
    description: 'Maintain a 7-day streak',
    icon: 'flame',
  },
];

const DEFAULT_PROGRESS: UserProgress = {
  name: '',
  totalXP: 0,
  currentStreak: 0,
  lastActiveDate: '',
  badges: DEFAULT_BADGES,
  lessonProgress: {},
  settings: {
    soundEnabled: true,
    voiceEnabled: true,
  },
};

export function getProgress(): UserProgress {
  if (typeof window === 'undefined') {
    return DEFAULT_PROGRESS;
  }
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Merge with defaults to handle any missing fields
      return { ...DEFAULT_PROGRESS, ...parsed, badges: parsed.badges || DEFAULT_BADGES };
    }
  } catch (e) {
    console.error('Failed to load progress:', e);
  }
  
  return DEFAULT_PROGRESS;
}

export function saveProgress(progress: UserProgress): void {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Failed to save progress:', e);
  }
}

export function addXP(amount: number): UserProgress {
  const progress = getProgress();
  progress.totalXP += amount;
  saveProgress(progress);
  return progress;
}

export function updateStreak(): UserProgress {
  const progress = getProgress();
  const today = new Date().toDateString();
  const lastActive = progress.lastActiveDate;
  
  if (lastActive === today) {
    return progress; // Already active today
  }
  
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (lastActive === yesterday.toDateString()) {
    progress.currentStreak += 1;
  } else if (lastActive !== today) {
    progress.currentStreak = 1; // Reset streak
  }
  
  progress.lastActiveDate = today;
  saveProgress(progress);
  
  // Check for streak badge
  if (progress.currentStreak >= 7) {
    unlockBadge('streak-hero');
  }
  
  return progress;
}

export function unlockBadge(badgeId: string): UserProgress {
  const progress = getProgress();
  const badge = progress.badges.find(b => b.id === badgeId);
  
  if (badge && !badge.unlockedAt) {
    badge.unlockedAt = new Date().toISOString();
    saveProgress(progress);
  }
  
  return progress;
}

export function updateLessonProgress(
  moduleId: string,
  itemId: string
): UserProgress {
  const progress = getProgress();
  
  if (!progress.lessonProgress[moduleId]) {
    progress.lessonProgress[moduleId] = {
      moduleId,
      completedItems: [],
      quizScores: [],
      lastAccessed: new Date().toISOString(),
    };
  }
  
  const lesson = progress.lessonProgress[moduleId];
  
  if (!lesson.completedItems.includes(itemId)) {
    lesson.completedItems.push(itemId);
  }
  
  lesson.lastAccessed = new Date().toISOString();
  saveProgress(progress);
  
  // Check for first lesson badge
  const totalCompleted = Object.values(progress.lessonProgress)
    .reduce((sum, l) => sum + l.completedItems.length, 0);
  
  if (totalCompleted === 1) {
    unlockBadge('first-lesson');
  }
  
  // Check module-specific badges
  if (moduleId === 'alphabet' && lesson.completedItems.length >= 26) {
    unlockBadge('alphabet-master');
  }
  
  if (moduleId === 'numbers' && lesson.completedItems.length >= 20) {
    unlockBadge('number-wizard');
  }
  
  return progress;
}

export function addQuizScore(moduleId: string, score: number): UserProgress {
  const progress = getProgress();
  
  if (!progress.lessonProgress[moduleId]) {
    progress.lessonProgress[moduleId] = {
      moduleId,
      completedItems: [],
      quizScores: [],
      lastAccessed: new Date().toISOString(),
    };
  }
  
  progress.lessonProgress[moduleId].quizScores.push(score);
  saveProgress(progress);
  
  return progress;
}

export function setUserName(name: string): UserProgress {
  const progress = getProgress();
  progress.name = name;
  saveProgress(progress);
  return progress;
}

export function updateSettings(settings: Partial<UserProgress['settings']>): UserProgress {
  const progress = getProgress();
  progress.settings = { ...progress.settings, ...settings };
  saveProgress(progress);
  return progress;
}
