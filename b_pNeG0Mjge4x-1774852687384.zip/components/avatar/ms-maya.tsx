'use client';

import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import Image from 'next/image';

export type AvatarExpression = 'neutral' | 'happy' | 'thinking' | 'excited' | 'encouraging';

interface MsMayaProps {
  expression?: AvatarExpression;
  isSpeaking?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const expressionImages: Record<AvatarExpression, string> = {
  neutral: '/avatars/maya-neutral.jpg',
  happy: '/avatars/maya-happy.jpg',
  thinking: '/avatars/maya-thinking.jpg',
  excited: '/avatars/maya-excited.jpg',
  encouraging: '/avatars/maya-encouraging.jpg',
};

export function MsMaya({ 
  expression = 'neutral', 
  isSpeaking = false,
  size = 'md',
  className 
}: MsMayaProps) {
  const [currentExpression, setCurrentExpression] = useState<AvatarExpression>(expression);
  const [isAnimating, setIsAnimating] = useState(false);

  // Update expression with smooth transition
  useEffect(() => {
    if (expression !== currentExpression) {
      setIsAnimating(true);
      const timeout = setTimeout(() => {
        setCurrentExpression(expression);
        setIsAnimating(false);
      }, 150);
      return () => clearTimeout(timeout);
    }
  }, [expression, currentExpression]);

  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-40 h-40',
    lg: 'w-56 h-56',
  };

  const imageSizes = {
    sm: 96,
    md: 160,
    lg: 224,
  };

  return (
    <div 
      className={cn(
        'relative animate-float',
        sizeClasses[size],
        className
      )}
      role="img"
      aria-label="Ms. Maya, your AI tutor"
    >
      {/* Glow effect behind avatar */}
      <div className="absolute inset-0 rounded-full bg-primary/30 blur-xl animate-pulse-glow" />
      
      {/* Main avatar container */}
      <div 
        className={cn(
          'relative w-full h-full rounded-full overflow-hidden border-4 border-primary/40 shadow-xl transition-all duration-300',
          isSpeaking && 'ring-4 ring-primary/50 ring-offset-2 ring-offset-background',
          isAnimating && 'scale-95 opacity-80'
        )}
      >
        <Image
          src={expressionImages[currentExpression]}
          alt={`Ms. Maya - ${currentExpression} expression`}
          width={imageSizes[size]}
          height={imageSizes[size]}
          className={cn(
            'w-full h-full object-cover transition-transform duration-300',
            isSpeaking && 'scale-105'
          )}
          priority
        />

        {/* Speaking indicator overlay */}
        {isSpeaking && (
          <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent animate-pulse" />
        )}
      </div>

      {/* Sound waves when speaking */}
      {isSpeaking && (
        <div className="absolute -right-2 top-1/2 -translate-y-1/2 flex flex-col gap-1">
          <div className="w-3 h-1 bg-primary rounded-full animate-pulse" style={{ animationDelay: '0ms' }} />
          <div className="w-4 h-1 bg-primary rounded-full animate-pulse" style={{ animationDelay: '100ms' }} />
          <div className="w-2 h-1 bg-primary rounded-full animate-pulse" style={{ animationDelay: '200ms' }} />
        </div>
      )}

      {/* Sparkle effects for excited expression */}
      {currentExpression === 'excited' && (
        <>
          <div className="absolute -top-1 -right-1 w-4 h-4">
            <svg viewBox="0 0 24 24" fill="currentColor" className="text-yellow-400 animate-pulse">
              <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
            </svg>
          </div>
          <div className="absolute -top-2 -left-1 w-3 h-3">
            <svg viewBox="0 0 24 24" fill="currentColor" className="text-yellow-300 animate-pulse" style={{ animationDelay: '150ms' }}>
              <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
            </svg>
          </div>
        </>
      )}

      {/* Heart for encouraging expression */}
      {currentExpression === 'encouraging' && (
        <div className="absolute -top-2 right-0 w-5 h-5 text-pink-400 animate-bounce">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
      )}

      {/* Floating star decoration */}
      <div className="absolute -top-3 -right-3 w-5 h-5">
        <svg viewBox="0 0 24 24" fill="currentColor" className="text-yellow-400 animate-pulse">
          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
        </svg>
      </div>
    </div>
  );
}
