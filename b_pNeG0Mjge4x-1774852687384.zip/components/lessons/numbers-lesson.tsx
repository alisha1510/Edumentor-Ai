'use client';

import { useState, useCallback } from 'react';
import { NUMBERS_DATA } from '@/lib/lesson-data';
import { updateLessonProgress, addXP, getProgress } from '@/lib/progress-store';
import { useVoice } from '@/hooks/use-voice';
import { MsMaya } from '@/components/avatar/ms-maya';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ArrowLeft, Volume2, Check } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

interface NumbersLessonProps {
  onBack: () => void;
  onXPGain: (amount: number) => void;
}

export function NumbersLesson({ onBack, onXPGain }: NumbersLessonProps) {
  const [selectedNumber, setSelectedNumber] = useState<typeof NUMBERS_DATA[0] | null>(null);
  const [completedNumbers, setCompletedNumbers] = useState<string[]>(() => {
    const progress = getProgress();
    return progress.lessonProgress['numbers']?.completedItems || [];
  });
  const [expression, setExpression] = useState<AvatarExpression>('neutral');
  
  const { speak, isSpeaking } = useVoice({
    onSpeakStart: () => setExpression('happy'),
    onSpeakEnd: () => setExpression('neutral'),
  });

  const handleNumberClick = useCallback((num: typeof NUMBERS_DATA[0]) => {
    setSelectedNumber(num);
    setExpression('excited');
    
    const message = `This is number ${num.number}! ${num.word}! Can you count ${num.number} ${num.objects}?`;
    speak(message);
    
    const numId = num.number.toString();
    if (!completedNumbers.includes(numId)) {
      setCompletedNumbers(prev => [...prev, numId]);
      updateLessonProgress('numbers', numId);
      addXP(5);
      onXPGain(5);
    }
  }, [completedNumbers, speak, onXPGain]);

  const handleSayAgain = useCallback(() => {
    if (selectedNumber) {
      speak(`${selectedNumber.word}! Count ${selectedNumber.number} ${selectedNumber.objects} with me!`);
    }
  }, [selectedNumber, speak]);

  // Generate visual objects for counting
  const renderObjects = (count: number, objectType: string) => {
    const emojis: Record<string, string> = {
      star: '\u2605',
      hearts: '\u2665',
      balloons: '\u25CF',
      flowers: '\u273F',
      butterflies: '\u2766',
      cookies: '\u25CB',
      clouds: '\u2601',
      crayons: '\u25A0',
      birds: '\u2708',
      apples: '\u25CF',
      leaves: '\u2766',
      eggs: '\u25CB',
      candies: '\u25C6',
      fish: '\u25CA',
      bubbles: '\u25CB',
      cupcakes: '\u25B2',
      strawberries: '\u25CF',
      pencils: '\u2758',
      raindrops: '\u25CF',
      stars: '\u2605',
    };
    
    const emoji = emojis[objectType] || '\u25CF';
    return Array.from({ length: Math.min(count, 10) }, (_, i) => (
      <span key={i} className="text-2xl animate-bounce-in" style={{ animationDelay: `${i * 0.1}s` }}>
        {emoji}
      </span>
    ));
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="h-6 w-6" />
          <span className="sr-only">Back to lessons</span>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Number Fun</h1>
          <p className="text-muted-foreground">
            {completedNumbers.length} of 20 numbers learned
          </p>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-4 overflow-auto">
        {/* Avatar and selected number display */}
        <div className="lg:w-1/3 flex flex-col items-center gap-4">
          <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" />
          
          {selectedNumber ? (
            <Card className="w-full p-6 text-center bg-card">
              <div className="text-8xl font-bold text-primary mb-4">
                {selectedNumber.number}
              </div>
              <p className="text-2xl font-semibold text-foreground mb-2">
                {selectedNumber.word}
              </p>
              <div className="flex flex-wrap justify-center gap-2 mb-4 min-h-[60px]">
                {renderObjects(selectedNumber.number, selectedNumber.objects)}
              </div>
              <p className="text-lg text-muted-foreground mb-4">
                {selectedNumber.number} {selectedNumber.objects}
              </p>
              <Button 
                onClick={handleSayAgain}
                disabled={isSpeaking}
                className="gap-2"
              >
                <Volume2 className="h-5 w-5" />
                Count again!
              </Button>
            </Card>
          ) : (
            <Card className="w-full p-6 text-center bg-card">
              <p className="text-xl text-muted-foreground">
                Tap a number to learn it!
              </p>
            </Card>
          )}
        </div>

        {/* Numbers grid */}
        <div className="lg:w-2/3">
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
            {NUMBERS_DATA.map((item) => {
              const numId = item.number.toString();
              const isCompleted = completedNumbers.includes(numId);
              const isSelected = selectedNumber?.number === item.number;
              
              return (
                <button
                  key={item.number}
                  onClick={() => handleNumberClick(item)}
                  className={cn(
                    'relative aspect-square rounded-xl text-3xl font-bold transition-all duration-200',
                    'flex items-center justify-center',
                    'hover:scale-105 active:scale-95',
                    'focus:outline-none focus:ring-4 focus:ring-primary/50',
                    isSelected
                      ? 'bg-primary text-primary-foreground shadow-lg scale-105'
                      : isCompleted
                        ? 'bg-success text-success-foreground'
                        : 'bg-secondary text-secondary-foreground hover:bg-primary/20'
                  )}
                  aria-label={`Number ${item.number}, ${item.word}`}
                >
                  {item.number}
                  {isCompleted && !isSelected && (
                    <Check className="absolute top-1 right-1 h-4 w-4" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
