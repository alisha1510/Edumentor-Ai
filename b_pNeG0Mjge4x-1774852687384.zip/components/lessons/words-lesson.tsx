'use client';

import { useState, useCallback, useMemo } from 'react';
import { FIRST_WORDS_DATA } from '@/lib/lesson-data';
import { updateLessonProgress, addXP, getProgress } from '@/lib/progress-store';
import { useVoice } from '@/hooks/use-voice';
import { MsMaya } from '@/components/avatar/ms-maya';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ArrowLeft, Volume2, Check } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

interface WordsLessonProps {
  onBack: () => void;
  onXPGain: (amount: number) => void;
}

export function WordsLesson({ onBack, onXPGain }: WordsLessonProps) {
  const [selectedWord, setSelectedWord] = useState<typeof FIRST_WORDS_DATA[0] | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [completedWords, setCompletedWords] = useState<string[]>(() => {
    const progress = getProgress();
    return progress.lessonProgress['words']?.completedItems || [];
  });
  const [expression, setExpression] = useState<AvatarExpression>('neutral');
  
  const { speak, isSpeaking } = useVoice({
    onSpeakStart: () => setExpression('happy'),
    onSpeakEnd: () => setExpression('neutral'),
  });

  const categories = useMemo(() => {
    const cats = ['All', ...new Set(FIRST_WORDS_DATA.map(w => w.category))];
    return cats;
  }, []);

  const filteredWords = useMemo(() => {
    if (selectedCategory === 'All') return FIRST_WORDS_DATA;
    return FIRST_WORDS_DATA.filter(w => w.category === selectedCategory);
  }, [selectedCategory]);

  const handleWordClick = useCallback((word: typeof FIRST_WORDS_DATA[0]) => {
    setSelectedWord(word);
    setExpression('excited');
    
    const message = `This is "${word.word}"! Can you say ${word.word}?`;
    speak(message);
    
    if (!completedWords.includes(word.word)) {
      setCompletedWords(prev => [...prev, word.word]);
      updateLessonProgress('words', word.word);
      addXP(5);
      onXPGain(5);
    }
  }, [completedWords, speak, onXPGain]);

  const handleSayAgain = useCallback(() => {
    if (selectedWord) {
      speak(`${selectedWord.word}! Great job learning "${selectedWord.word}"!`);
    }
  }, [selectedWord, speak]);

  const handleSpellWord = useCallback(() => {
    if (selectedWord) {
      const spelled = selectedWord.word.split('').join(', ');
      speak(`Let's spell ${selectedWord.word}: ${spelled}. ${selectedWord.word}!`);
    }
  }, [selectedWord, speak]);

  // Simple word illustration using CSS shapes
  const getWordIllustration = (word: string) => {
    const illustrations: Record<string, React.ReactNode> = {
      Dog: <div className="text-6xl">{'\uD83D\uDC15'}</div>,
      Cat: <div className="text-6xl">{'\uD83D\uDC31'}</div>,
      Bird: <div className="text-6xl">{'\uD83D\uDC26'}</div>,
      Fish: <div className="text-6xl">{'\uD83D\uDC1F'}</div>,
      Bear: <div className="text-6xl">{'\uD83D\uDC3B'}</div>,
      Apple: <div className="text-6xl">{'\uD83C\uDF4E'}</div>,
      Banana: <div className="text-6xl">{'\uD83C\uDF4C'}</div>,
      Milk: <div className="text-6xl">{'\uD83E\uDD5B'}</div>,
      Cookie: <div className="text-6xl">{'\uD83C\uDF6A'}</div>,
      Bread: <div className="text-6xl">{'\uD83C\uDF5E'}</div>,
      Mom: <div className="text-6xl">{'\uD83D\uDC69'}</div>,
      Dad: <div className="text-6xl">{'\uD83D\uDC68'}</div>,
      Baby: <div className="text-6xl">{'\uD83D\uDC76'}</div>,
      Home: <div className="text-6xl">{'\uD83C\uDFE0'}</div>,
      Love: <div className="text-6xl">{'\u2764\uFE0F'}</div>,
      Sun: <div className="text-6xl">{'\u2600\uFE0F'}</div>,
      Moon: <div className="text-6xl">{'\uD83C\uDF19'}</div>,
      Star: <div className="text-6xl">{'\u2B50'}</div>,
      Tree: <div className="text-6xl">{'\uD83C\uDF33'}</div>,
      Flower: <div className="text-6xl">{'\uD83C\uDF38'}</div>,
    };
    return illustrations[word] || <div className="text-6xl">{'\u2753'}</div>;
  };

  const categoryColors: Record<string, string> = {
    All: 'bg-primary',
    Animals: 'bg-amber-500',
    Food: 'bg-green-500',
    Family: 'bg-pink-500',
    Nature: 'bg-blue-500',
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="h-6 w-6" />
          <span className="sr-only">Back to lessons</span>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">First Words</h1>
          <p className="text-muted-foreground">
            {completedWords.length} of {FIRST_WORDS_DATA.length} words learned
          </p>
        </div>
      </div>

      {/* Category tabs */}
      <div className="flex gap-2 p-4 overflow-x-auto border-b border-border">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={cn(
              'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
              selectedCategory === category
                ? `${categoryColors[category]} text-white`
                : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
            )}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-4 overflow-auto">
        {/* Avatar and selected word display */}
        <div className="lg:w-1/3 flex flex-col items-center gap-4">
          <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" />
          
          {selectedWord ? (
            <Card className="w-full p-6 text-center bg-card">
              <div className="mb-4 flex justify-center">
                {getWordIllustration(selectedWord.word)}
              </div>
              <div className="text-4xl font-bold text-primary mb-2">
                {selectedWord.word}
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Category: {selectedWord.category}
              </p>
              <div className="flex flex-col gap-2">
                <Button 
                  onClick={handleSayAgain}
                  disabled={isSpeaking}
                  className="gap-2"
                >
                  <Volume2 className="h-5 w-5" />
                  Say it!
                </Button>
                <Button 
                  variant="outline"
                  onClick={handleSpellWord}
                  disabled={isSpeaking}
                >
                  Spell it!
                </Button>
              </div>
            </Card>
          ) : (
            <Card className="w-full p-6 text-center bg-card">
              <p className="text-xl text-muted-foreground">
                Tap a word to learn it!
              </p>
            </Card>
          )}
        </div>

        {/* Words grid */}
        <div className="lg:w-2/3">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {filteredWords.map((item) => {
              const isCompleted = completedWords.includes(item.word);
              const isSelected = selectedWord?.word === item.word;
              
              return (
                <button
                  key={item.word}
                  onClick={() => handleWordClick(item)}
                  className={cn(
                    'relative p-4 rounded-xl transition-all duration-200',
                    'flex flex-col items-center justify-center gap-2',
                    'hover:scale-105 active:scale-95',
                    'focus:outline-none focus:ring-4 focus:ring-primary/50',
                    isSelected
                      ? 'bg-primary text-primary-foreground shadow-lg scale-105'
                      : isCompleted
                        ? 'bg-success text-success-foreground'
                        : 'bg-card text-card-foreground border-2 border-border hover:border-primary'
                  )}
                  aria-label={`Word: ${item.word}`}
                >
                  <div className="text-3xl">
                    {getWordIllustration(item.word)}
                  </div>
                  <span className="text-lg font-bold">{item.word}</span>
                  {isCompleted && !isSelected && (
                    <Check className="absolute top-2 right-2 h-4 w-4" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
