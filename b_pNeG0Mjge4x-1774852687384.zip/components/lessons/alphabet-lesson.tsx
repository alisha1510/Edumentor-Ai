'use client';

import { useState, useCallback } from 'react';
import { ALPHABET_DATA } from '@/lib/lesson-data';
import { updateLessonProgress, addXP, getProgress } from '@/lib/progress-store';
import { useVoice } from '@/hooks/use-voice';
import { MsMaya } from '@/components/avatar/ms-maya';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ArrowLeft, Volume2, Check } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

interface AlphabetLessonProps {
  onBack: () => void;
  onXPGain: (amount: number) => void;
}

export function AlphabetLesson({ onBack, onXPGain }: AlphabetLessonProps) {
  const [selectedLetter, setSelectedLetter] = useState<typeof ALPHABET_DATA[0] | null>(null);
  const [completedLetters, setCompletedLetters] = useState<string[]>(() => {
    const progress = getProgress();
    return progress.lessonProgress['alphabet']?.completedItems || [];
  });
  const [expression, setExpression] = useState<AvatarExpression>('neutral');
  
  const { speak, isSpeaking } = useVoice({
    onSpeakStart: () => setExpression('happy'),
    onSpeakEnd: () => setExpression('neutral'),
  });

  const handleLetterClick = useCallback((letter: typeof ALPHABET_DATA[0]) => {
    setSelectedLetter(letter);
    setExpression('excited');
    
    const message = `${letter.letter} is for ${letter.word}! Can you say ${letter.letter}?`;
    speak(message);
    
    if (!completedLetters.includes(letter.letter)) {
      setCompletedLetters(prev => [...prev, letter.letter]);
      updateLessonProgress('alphabet', letter.letter);
      addXP(5);
      onXPGain(5);
    }
  }, [completedLetters, speak, onXPGain]);

  const handleSayAgain = useCallback(() => {
    if (selectedLetter) {
      speak(`${selectedLetter.letter} is for ${selectedLetter.word}!`);
    }
  }, [selectedLetter, speak]);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="h-6 w-6" />
          <span className="sr-only">Back to lessons</span>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">ABC Adventure</h1>
          <p className="text-muted-foreground">
            {completedLetters.length} of 26 letters learned
          </p>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-4 overflow-auto">
        {/* Avatar and selected letter display */}
        <div className="lg:w-1/3 flex flex-col items-center gap-4">
          <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" />
          
          {selectedLetter ? (
            <Card className="w-full p-6 text-center bg-card">
              <div className="text-8xl font-bold text-primary mb-4">
                {selectedLetter.letter}
              </div>
              <p className="text-2xl font-semibold text-foreground mb-2">
                {selectedLetter.letter} is for {selectedLetter.word}
              </p>
              <p className="text-lg text-muted-foreground mb-4">
                Sound: {selectedLetter.sound}
              </p>
              <Button 
                onClick={handleSayAgain}
                disabled={isSpeaking}
                className="gap-2"
              >
                <Volume2 className="h-5 w-5" />
                Say it again!
              </Button>
            </Card>
          ) : (
            <Card className="w-full p-6 text-center bg-card">
              <p className="text-xl text-muted-foreground">
                Tap a letter to learn it!
              </p>
            </Card>
          )}
        </div>

        {/* Alphabet grid */}
        <div className="lg:w-2/3">
          <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7 gap-3">
            {ALPHABET_DATA.map((item) => {
              const isCompleted = completedLetters.includes(item.letter);
              const isSelected = selectedLetter?.letter === item.letter;
              
              return (
                <button
                  key={item.letter}
                  onClick={() => handleLetterClick(item)}
                  className={cn(
                    'relative aspect-square rounded-xl text-3xl font-bold transition-all duration-200',
                    'flex items-center justify-center',
                    'hover:scale-105 active:scale-95',
                    'focus:outline-none focus:ring-4 focus:ring-primary/50',
                    isSelected
                      ? 'bg-primary text-primary-foreground shadow-lg scale-105'
                      : isCompleted
                        ? 'bg-success text-success-foreground'
                        : 'bg-secondary text-secondary-foreground hover:bg-primary/20'
                  )}
                  aria-label={`Letter ${item.letter} for ${item.word}`}
                >
                  {item.letter}
                  {isCompleted && !isSelected && (
                    <Check className="absolute top-1 right-1 h-4 w-4" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
