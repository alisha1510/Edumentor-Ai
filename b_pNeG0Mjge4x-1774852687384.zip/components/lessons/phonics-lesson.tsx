'use client';

import { useState, useCallback } from 'react';
import { PHONICS_DATA } from '@/lib/lesson-data';
import { updateLessonProgress, addXP, getProgress } from '@/lib/progress-store';
import { useVoice } from '@/hooks/use-voice';
import { MsMaya } from '@/components/avatar/ms-maya';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ArrowLeft, Volume2, Check, ChevronLeft, ChevronRight } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

interface PhonicsLessonProps {
  onBack: () => void;
  onXPGain: (amount: number) => void;
}

export function PhonicsLesson({ onBack, onXPGain }: PhonicsLessonProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [completedSounds, setCompletedSounds] = useState<string[]>(() => {
    const progress = getProgress();
    return progress.lessonProgress['phonics']?.completedItems || [];
  });
  const [expression, setExpression] = useState<AvatarExpression>('neutral');
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  
  const currentSound = PHONICS_DATA[currentIndex];
  
  const { speak, isSpeaking } = useVoice({
    onSpeakStart: () => setExpression('happy'),
    onSpeakEnd: () => setExpression('neutral'),
  });

  const handleSoundIntro = useCallback(() => {
    setExpression('excited');
    const message = `The sound is "${currentSound.sound}"! Listen: ${currentSound.words.join(', ')}. They all have the "${currentSound.sound}" sound!`;
    speak(message);
    
    if (!completedSounds.includes(currentSound.sound)) {
      setCompletedSounds(prev => [...prev, currentSound.sound]);
      updateLessonProgress('phonics', currentSound.sound);
      addXP(10);
      onXPGain(10);
    }
  }, [currentSound, completedSounds, speak, onXPGain]);

  const handleWordClick = useCallback((word: string) => {
    setSelectedWord(word);
    setExpression('encouraging');
    speak(`${word}! Can you hear the "${currentSound.sound}" sound in ${word}?`);
  }, [currentSound.sound, speak]);

  const handleNext = useCallback(() => {
    if (currentIndex < PHONICS_DATA.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedWord(null);
      setExpression('neutral');
    }
  }, [currentIndex]);

  const handlePrevious = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setSelectedWord(null);
      setExpression('neutral');
    }
  }, [currentIndex]);

  const handleReadExample = useCallback(() => {
    speak(currentSound.example);
  }, [currentSound.example, speak]);

  const isCompleted = completedSounds.includes(currentSound.sound);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="h-6 w-6" />
          <span className="sr-only">Back to lessons</span>
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-foreground">Sound Safari</h1>
          <p className="text-muted-foreground">
            {completedSounds.length} of {PHONICS_DATA.length} sounds learned
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handlePrevious}
            disabled={currentIndex === 0}
          >
            <ChevronLeft className="h-5 w-5" />
            <span className="sr-only">Previous sound</span>
          </Button>
          <span className="text-sm font-medium text-muted-foreground min-w-[60px] text-center">
            {currentIndex + 1} / {PHONICS_DATA.length}
          </span>
          <Button
            variant="outline"
            size="icon"
            onClick={handleNext}
            disabled={currentIndex === PHONICS_DATA.length - 1}
          >
            <ChevronRight className="h-5 w-5" />
            <span className="sr-only">Next sound</span>
          </Button>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-4 overflow-auto">
        {/* Avatar and sound display */}
        <div className="lg:w-1/3 flex flex-col items-center gap-4">
          <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" />
          
          <Card className={cn(
            'w-full p-6 text-center bg-card transition-all',
            isCompleted && 'ring-2 ring-success'
          )}>
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-6xl font-bold text-primary">
                -{currentSound.sound}
              </span>
              {isCompleted && <Check className="h-8 w-8 text-success" />}
            </div>
            
            <Button 
              onClick={handleSoundIntro}
              disabled={isSpeaking}
              className="gap-2 mb-4"
              size="lg"
            >
              <Volume2 className="h-5 w-5" />
              Hear the sound!
            </Button>
            
            <div className="bg-secondary/50 rounded-lg p-4 mt-4">
              <p className="text-sm text-muted-foreground mb-2">Example sentence:</p>
              <p className="text-lg font-medium text-foreground italic">
                &quot;{currentSound.example}&quot;
              </p>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleReadExample}
                disabled={isSpeaking}
                className="mt-2"
              >
                <Volume2 className="h-4 w-4 mr-1" />
                Read it
              </Button>
            </div>
          </Card>
        </div>

        {/* Words with this sound */}
        <div className="lg:w-2/3">
          <h2 className="text-xl font-semibold text-foreground mb-4">
            Words with &quot;-{currentSound.sound}&quot; sound:
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {currentSound.words.map((word) => (
              <button
                key={word}
                onClick={() => handleWordClick(word)}
                className={cn(
                  'p-6 rounded-xl text-2xl font-bold transition-all duration-200',
                  'hover:scale-105 active:scale-95',
                  'focus:outline-none focus:ring-4 focus:ring-primary/50',
                  selectedWord === word
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-card text-card-foreground border-2 border-border hover:border-primary'
                )}
              >
                <span className="text-muted-foreground">{word.slice(0, -currentSound.sound.length)}</span>
                <span className="text-primary">{currentSound.sound}</span>
              </button>
            ))}
          </div>
          
          {/* Sound family indicators */}
          <div className="mt-6 flex flex-wrap gap-2">
            {PHONICS_DATA.map((sound, index) => (
              <button
                key={sound.sound}
                onClick={() => {
                  setCurrentIndex(index);
                  setSelectedWord(null);
                }}
                className={cn(
                  'px-3 py-1 rounded-full text-sm font-medium transition-all',
                  currentIndex === index
                    ? 'bg-primary text-primary-foreground'
                    : completedSounds.includes(sound.sound)
                      ? 'bg-success/20 text-success'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                )}
              >
                -{sound.sound}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
