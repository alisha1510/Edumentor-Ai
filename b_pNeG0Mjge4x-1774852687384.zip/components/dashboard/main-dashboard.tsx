'use client';

import { useState, useEffect, useCallback } from 'react';
import { MsMaya } from '@/components/avatar/ms-maya';
import { XPDisplay } from '@/components/gamification/xp-display';
import { BadgeDisplay } from '@/components/gamification/badge-display';
import { LessonCard } from './lesson-card';
import { WelcomeModal } from './welcome-modal';
import { AlphabetLesson } from '@/components/lessons/alphabet-lesson';
import { NumbersLesson } from '@/components/lessons/numbers-lesson';
import { PhonicsLesson } from '@/components/lessons/phonics-lesson';
import { WordsLesson } from '@/components/lessons/words-lesson';
import { AIChat } from '@/components/chat/ai-chat';
import { Quiz, generateAlphabetQuiz, generateNumbersQuiz, generatePhonicsQuiz } from '@/components/gamification/quiz';
import { Confetti } from '@/components/gamification/confetti';
import { useVoice } from '@/hooks/use-voice';
import { 
  getProgress, 
  updateStreak, 
  type UserProgress 
} from '@/lib/progress-store';
import { LESSON_MODULES } from '@/lib/lesson-data';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MessageCircle, Settings, Award } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

type View = 'dashboard' | 'alphabet' | 'numbers' | 'phonics' | 'words' | 'chat' | 'quiz-alphabet' | 'quiz-numbers' | 'quiz-phonics' | 'badges';

export function MainDashboard() {
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [showWelcome, setShowWelcome] = useState(false);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [expression, setExpression] = useState<AvatarExpression>('happy');
  const [showConfetti, setShowConfetti] = useState(false);
  const [showXPAnimation, setShowXPAnimation] = useState(false);

  const { speak, isSpeaking } = useVoice({
    onSpeakStart: () => setExpression('happy'),
    onSpeakEnd: () => setExpression('neutral'),
  });

  // Initialize progress and check for first visit
  useEffect(() => {
    const savedProgress = getProgress();
    setProgress(savedProgress);
    
    if (!savedProgress.name) {
      setShowWelcome(true);
    } else {
      // Update streak on visit
      const updated = updateStreak();
      setProgress(updated);
    }
  }, []);

  const handleWelcomeComplete = useCallback((name: string) => {
    setShowWelcome(false);
    const updated = updateStreak();
    setProgress(updated);
  }, []);

  const handleXPGain = useCallback((amount: number) => {
    setShowXPAnimation(true);
    setTimeout(() => {
      setProgress(getProgress());
      setShowXPAnimation(false);
    }, 500);
  }, []);

  const handleQuizComplete = useCallback((score: number, total: number) => {
    if (score >= Math.ceil(total * 0.8)) {
      setShowConfetti(true);
    }
    setProgress(getProgress());
  }, []);

  const handleBackToDashboard = useCallback(() => {
    setCurrentView('dashboard');
    setProgress(getProgress());
  }, []);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const getLessonProgress = (moduleId: string) => {
    if (!progress) return 0;
    return progress.lessonProgress[moduleId]?.completedItems.length || 0;
  };

  // Loading state
  if (!progress) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-2xl text-muted-foreground">Loading...</div>
      </div>
    );
  }

  // Welcome modal for first-time users
  if (showWelcome) {
    return <WelcomeModal onComplete={handleWelcomeComplete} />;
  }

  // Render current view
  if (currentView === 'alphabet') {
    return <AlphabetLesson onBack={handleBackToDashboard} onXPGain={handleXPGain} />;
  }
  
  if (currentView === 'numbers') {
    return <NumbersLesson onBack={handleBackToDashboard} onXPGain={handleXPGain} />;
  }
  
  if (currentView === 'phonics') {
    return <PhonicsLesson onBack={handleBackToDashboard} onXPGain={handleXPGain} />;
  }
  
  if (currentView === 'words') {
    return <WordsLesson onBack={handleBackToDashboard} onXPGain={handleXPGain} />;
  }
  
  if (currentView === 'chat') {
    return <AIChat onBack={handleBackToDashboard} userName={progress.name} />;
  }
  
  if (currentView === 'quiz-alphabet') {
    return (
      <Quiz 
        moduleId="alphabet"
        title="ABC Quiz"
        questions={generateAlphabetQuiz()}
        onComplete={handleQuizComplete}
        onBack={handleBackToDashboard}
      />
    );
  }
  
  if (currentView === 'quiz-numbers') {
    return (
      <Quiz 
        moduleId="numbers"
        title="Numbers Quiz"
        questions={generateNumbersQuiz()}
        onComplete={handleQuizComplete}
        onBack={handleBackToDashboard}
      />
    );
  }
  
  if (currentView === 'quiz-phonics') {
    return (
      <Quiz 
        moduleId="phonics"
        title="Phonics Quiz"
        questions={generatePhonicsQuiz()}
        onComplete={handleQuizComplete}
        onBack={handleBackToDashboard}
      />
    );
  }
  
  if (currentView === 'badges') {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button variant="ghost" size="icon" onClick={handleBackToDashboard}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
            </Button>
            <h1 className="text-3xl font-bold text-foreground">My Badges</h1>
          </div>
          <BadgeDisplay badges={progress.badges} />
        </div>
      </div>
    );
  }

  // Main dashboard view
  return (
    <div className="min-h-screen bg-background">
      <Confetti isActive={showConfetti} onComplete={() => setShowConfetti(false)} />
      
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">E</span>
            </div>
            <span className="font-bold text-xl text-foreground hidden sm:block">EduMentor AI</span>
          </div>
          
          <XPDisplay 
            xp={progress.totalXP} 
            streak={progress.currentStreak}
            showAnimation={showXPAnimation}
          />
          
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setCurrentView('badges')}
            >
              <Award className="h-5 w-5" />
              <span className="sr-only">Badges</span>
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
              <span className="sr-only">Settings</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Welcome section with avatar */}
        <section className="mb-8">
          <Card className="p-6 bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <MsMaya 
                expression={expression} 
                isSpeaking={isSpeaking} 
                size="md" 
              />
              <div className="text-center sm:text-left flex-1">
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  {getGreeting()}, {progress.name || 'Friend'}!
                </h1>
                <p className="text-lg text-muted-foreground mb-4">
                  Ready to learn something amazing today?
                </p>
                <Button 
                  onClick={() => {
                    setCurrentView('chat');
                    speak(`Hi ${progress.name || 'there'}! Let's have a fun learning adventure!`);
                  }}
                  size="lg"
                  className="gap-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  Chat with Ms. Maya
                </Button>
              </div>
            </div>
          </Card>
        </section>

        {/* Lesson modules */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">Learning Adventures</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {LESSON_MODULES.map((module) => (
              <LessonCard
                key={module.id}
                id={module.id}
                title={module.title}
                description={module.description}
                icon={module.icon}
                color={module.color}
                totalItems={module.totalItems}
                completedItems={getLessonProgress(module.id)}
                onClick={() => setCurrentView(module.id as View)}
                onQuizClick={
                  module.id === 'alphabet' ? () => setCurrentView('quiz-alphabet') :
                  module.id === 'numbers' ? () => setCurrentView('quiz-numbers') :
                  module.id === 'phonics' ? () => setCurrentView('quiz-phonics') :
                  undefined
                }
              />
            ))}
          </div>
        </section>

        {/* Badges preview */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-foreground">My Badges</h2>
            <Button variant="ghost" onClick={() => setCurrentView('badges')}>
              View All
            </Button>
          </div>
          <BadgeDisplay badges={progress.badges} />
        </section>
      </main>
    </div>
  );
}
