'use client';

import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { BookOpen, Hash, Volume2, MessageSquare, Play, Trophy } from 'lucide-react';

interface LessonCardProps {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  totalItems: number;
  completedItems: number;
  onClick: () => void;
  onQuizClick?: () => void;
}

const ICONS: Record<string, React.ReactNode> = {
  abc: <BookOpen className="h-8 w-8" />,
  '123': <Hash className="h-8 w-8" />,
  sound: <Volume2 className="h-8 w-8" />,
  book: <MessageSquare className="h-8 w-8" />,
};

export function LessonCard({
  title,
  description,
  icon,
  color,
  totalItems,
  completedItems,
  onClick,
  onQuizClick,
}: LessonCardProps) {
  const progress = totalItems > 0 ? (completedItems / totalItems) * 100 : 0;
  const isComplete = progress === 100;

  return (
    <Card 
      className={cn(
        'relative overflow-hidden transition-all duration-300',
        'hover:scale-105 hover:shadow-lg cursor-pointer',
        'group'
      )}
    >
      {/* Colored header */}
      <div className={cn('p-6 text-white', color)}>
        <div className="flex items-center justify-between">
          <div className="p-3 bg-white/20 rounded-xl">
            {ICONS[icon] || <BookOpen className="h-8 w-8" />}
          </div>
          {isComplete && (
            <div className="p-2 bg-white/20 rounded-full">
              <Trophy className="h-6 w-6" />
            </div>
          )}
        </div>
        <h3 className="text-2xl font-bold mt-4">{title}</h3>
        <p className="text-white/80 text-sm">{description}</p>
      </div>

      {/* Progress section */}
      <div className="p-4 bg-card">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-medium text-foreground">
            {completedItems}/{totalItems}
          </span>
        </div>
        <Progress value={progress} className="h-2 mb-4" />
        
        <div className="flex gap-2">
          <button
            onClick={onClick}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 py-3 rounded-xl',
              'font-semibold transition-all',
              'bg-primary text-primary-foreground hover:bg-primary/90'
            )}
          >
            <Play className="h-5 w-5" />
            Learn
          </button>
          
          {onQuizClick && completedItems >= 5 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onQuizClick();
              }}
              className={cn(
                'flex items-center justify-center gap-2 px-4 py-3 rounded-xl',
                'font-semibold transition-all',
                'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              )}
            >
              <Trophy className="h-5 w-5" />
              Quiz
            </button>
          )}
        </div>
      </div>
    </Card>
  );
}
