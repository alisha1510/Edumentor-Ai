'use client';

import { useState } from 'react';
import { MsMaya } from '@/components/avatar/ms-maya';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { setUserName } from '@/lib/progress-store';
import { useVoice } from '@/hooks/use-voice';

interface WelcomeModalProps {
  onComplete: (name: string) => void;
}

export function WelcomeModal({ onComplete }: WelcomeModalProps) {
  const [name, setName] = useState('');
  const [step, setStep] = useState<'welcome' | 'name'>('welcome');
  
  const { speak, isSpeaking } = useVoice();

  const handleStart = () => {
    speak("Hi there! I'm Ms. Maya, and I'll be your learning buddy! What's your name?");
    setStep('name');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim() || 'Friend';
    setUserName(trimmedName);
    speak(`Nice to meet you, ${trimmedName}! Let's learn together!`);
    setTimeout(() => {
      onComplete(trimmedName);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 text-center bg-card animate-bounce-in">
        <MsMaya 
          expression={step === 'welcome' ? 'excited' : 'encouraging'} 
          isSpeaking={isSpeaking}
          size="lg" 
          className="mx-auto mb-6" 
        />
        
        {step === 'welcome' ? (
          <>
            <h1 className="text-3xl font-bold text-foreground mb-4">
              Welcome to EduMentor AI!
            </h1>
            <p className="text-lg text-muted-foreground mb-6">
              Get ready to learn with your new AI friend, Ms. Maya!
            </p>
            <Button onClick={handleStart} size="lg" className="w-full text-lg">
              Let&apos;s Go!
            </Button>
          </>
        ) : (
          <form onSubmit={handleSubmit}>
            <h2 className="text-2xl font-bold text-foreground mb-4">
              What&apos;s your name?
            </h2>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Type your name..."
              autoFocus
              className="w-full px-4 py-3 rounded-xl text-xl text-center
                bg-input text-foreground placeholder:text-muted-foreground
                border-2 border-border focus:border-primary focus:outline-none
                transition-colors mb-4"
            />
            <Button type="submit" size="lg" className="w-full text-lg">
              Start Learning!
            </Button>
          </form>
        )}
      </Card>
    </div>
  );
}
