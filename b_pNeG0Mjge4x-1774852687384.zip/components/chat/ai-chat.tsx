'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport } from 'ai';
import { MsMaya } from '@/components/avatar/ms-maya';
import { useVoice } from '@/hooks/use-voice';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { Send, Volume2, Mic, MicOff, ArrowLeft } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

interface AIChatProps {
  onBack: () => void;
  userName?: string;
}

export function AIChat({ onBack, userName }: AIChatProps) {
  const [input, setInput] = useState('');
  const [expression, setExpression] = useState<AvatarExpression>('neutral');
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  
  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({ api: '/api/chat' }),
  });

  const isLoading = status === 'streaming' || status === 'submitted';

  const { speak, isSpeaking, stop: stopSpeaking } = useVoice({
    onSpeakStart: () => setExpression('happy'),
    onSpeakEnd: () => setExpression('neutral'),
  });

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Update expression based on status
  useEffect(() => {
    if (isLoading) {
      setExpression('thinking');
    } else if (!isSpeaking) {
      setExpression('neutral');
    }
  }, [isLoading, isSpeaking]);

  // Speak the last assistant message
  useEffect(() => {
    if (messages.length > 0 && status === 'ready') {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.role === 'assistant') {
        const text = lastMessage.parts
          ?.filter((p): p is { type: 'text'; text: string } => p.type === 'text')
          .map((p) => p.text)
          .join('') || '';
        if (text) {
          speak(text);
        }
      }
    }
  }, [messages, status, speak]);

  // Setup speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  const toggleListening = useCallback(() => {
    if (!recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      stopSpeaking();
      recognitionRef.current.start();
      setIsListening(true);
      setExpression('encouraging');
    }
  }, [isListening, stopSpeaking]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    
    stopSpeaking();
    setExpression('excited');
    sendMessage({ text: input });
    setInput('');
  };

  const handleSpeakMessage = useCallback((text: string) => {
    speak(text);
  }, [speak]);

  const getMessageText = (message: typeof messages[0]) => {
    return message.parts
      ?.filter((p): p is { type: 'text'; text: string } => p.type === 'text')
      .map((p) => p.text)
      .join('') || '';
  };

  // Send initial greeting
  useEffect(() => {
    if (messages.length === 0) {
      const greeting = userName 
        ? `Hi ${userName}! I'm Ms. Maya. What would you like to learn today?`
        : "Hi there! I'm Ms. Maya, your friendly learning buddy! What would you like to learn today?";
      speak(greeting);
      setExpression('excited');
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="h-6 w-6" />
          <span className="sr-only">Back to home</span>
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Chat with Ms. Maya</h1>
          <p className="text-muted-foreground">Ask me anything about learning!</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-4 p-4 overflow-hidden">
        {/* Avatar section */}
        <div className="lg:w-1/3 flex flex-col items-center gap-4">
          <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" />
          
          <Card className="w-full p-4 bg-card text-center">
            <p className="text-sm text-muted-foreground mb-2">
              {isSpeaking ? 'Ms. Maya is speaking...' : 
               isLoading ? 'Ms. Maya is thinking...' : 
               isListening ? 'Listening to you...' : 
               'Tap the microphone to talk!'}
            </p>
            <Button
              variant={isListening ? 'destructive' : 'outline'}
              size="lg"
              onClick={toggleListening}
              disabled={isLoading || isSpeaking}
              className="gap-2"
            >
              {isListening ? (
                <>
                  <MicOff className="h-5 w-5" />
                  Stop
                </>
              ) : (
                <>
                  <Mic className="h-5 w-5" />
                  Talk to me!
                </>
              )}
            </Button>
          </Card>
        </div>

        {/* Chat section */}
        <div className="lg:w-2/3 flex flex-col flex-1 min-h-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-4 mb-4">
            {messages.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground text-lg">
                  Say hello or ask me a question!
                </p>
                <div className="flex flex-wrap justify-center gap-2 mt-4">
                  {['What letter comes after B?', 'Can you count to 10?', 'What sound does C make?'].map((suggestion) => (
                    <Button
                      key={suggestion}
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        sendMessage({ text: suggestion });
                      }}
                      disabled={isLoading}
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            )}
            
            {messages.map((message) => {
              const text = getMessageText(message);
              const isUser = message.role === 'user';
              
              return (
                <div
                  key={message.id}
                  className={cn(
                    'flex gap-3',
                    isUser ? 'justify-end' : 'justify-start'
                  )}
                >
                  <Card className={cn(
                    'max-w-[80%] p-4',
                    isUser 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-card text-card-foreground'
                  )}>
                    <p className="text-lg leading-relaxed">{text}</p>
                    {!isUser && text && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSpeakMessage(text)}
                        disabled={isSpeaking}
                        className="mt-2 -mb-2"
                      >
                        <Volume2 className="h-4 w-4 mr-1" />
                        Listen
                      </Button>
                    )}
                  </Card>
                </div>
              );
            })}
            
            {isLoading && (
              <div className="flex justify-start">
                <Card className="bg-card text-card-foreground p-4">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </Card>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input form */}
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              disabled={isLoading}
              className={cn(
                'flex-1 px-4 py-3 rounded-xl text-lg',
                'bg-input text-foreground placeholder:text-muted-foreground',
                'border-2 border-border focus:border-primary focus:outline-none',
                'transition-colors'
              )}
            />
            <Button
              type="submit"
              size="lg"
              disabled={!input.trim() || isLoading}
              className="px-6"
            >
              <Send className="h-5 w-5" />
              <span className="sr-only">Send message</span>
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

// Add type declarations for Web Speech API
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}
