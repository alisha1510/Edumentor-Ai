'use client';

import { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { MsMaya } from '@/components/avatar/ms-maya';
import { Confetti } from './confetti';
import { useVoice } from '@/hooks/use-voice';
import { addXP, addQuizScore } from '@/lib/progress-store';
import { cn } from '@/lib/utils';
import { ArrowLeft, Check, X } from 'lucide-react';
import type { AvatarExpression } from '@/components/avatar/ms-maya';

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface QuizProps {
  moduleId: string;
  title: string;
  questions: QuizQuestion[];
  onComplete: (score: number, total: number) => void;
  onBack: () => void;
}

export function Quiz({ moduleId, title, questions, onComplete, onBack }: QuizProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [expression, setExpression] = useState<AvatarExpression>('encouraging');
  const [quizComplete, setQuizComplete] = useState(false);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + (isAnswered ? 1 : 0)) / questions.length) * 100;

  const { speak, isSpeaking } = useVoice({
    onSpeakStart: () => {
      if (!isAnswered) setExpression('happy');
    },
    onSpeakEnd: () => {
      if (!isAnswered) setExpression('encouraging');
    },
  });

  const handleAnswer = useCallback((answerIndex: number) => {
    if (isAnswered) return;

    setSelectedAnswer(answerIndex);
    setIsAnswered(true);

    const isCorrect = answerIndex === currentQuestion.correctAnswer;
    
    if (isCorrect) {
      setScore(prev => prev + 1);
      setExpression('excited');
      setShowConfetti(true);
      speak(`Great job! ${currentQuestion.explanation}`);
      addXP(10);
    } else {
      setExpression('encouraging');
      const correctOption = currentQuestion.options[currentQuestion.correctAnswer];
      speak(`Good try! The answer is ${correctOption}. ${currentQuestion.explanation}`);
    }
  }, [isAnswered, currentQuestion, speak]);

  const handleNext = useCallback(() => {
    setShowConfetti(false);
    
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
      setExpression('encouraging');
    } else {
      // Quiz complete
      setQuizComplete(true);
      const finalScore = score + (selectedAnswer === currentQuestion.correctAnswer ? 1 : 0);
      const percentage = Math.round((finalScore / questions.length) * 100);
      addQuizScore(moduleId, percentage);
      
      if (percentage >= 80) {
        setShowConfetti(true);
        setExpression('excited');
        speak(`Amazing! You got ${finalScore} out of ${questions.length} correct! You're a superstar!`);
      } else if (percentage >= 50) {
        setExpression('happy');
        speak(`Good job! You got ${finalScore} out of ${questions.length} correct! Keep practicing!`);
      } else {
        setExpression('encouraging');
        speak(`You got ${finalScore} out of ${questions.length}. Let's practice more and try again!`);
      }
      
      onComplete(finalScore, questions.length);
    }
  }, [currentIndex, questions, score, selectedAnswer, currentQuestion, moduleId, speak, onComplete]);

  const readQuestion = useCallback(() => {
    speak(currentQuestion.question);
  }, [currentQuestion.question, speak]);

  const finalScore = useMemo(() => {
    if (!quizComplete) return null;
    return score + (selectedAnswer === currentQuestion?.correctAnswer ? 1 : 0);
  }, [quizComplete, score, selectedAnswer, currentQuestion]);

  if (quizComplete && finalScore !== null) {
    const percentage = Math.round((finalScore / questions.length) * 100);
    
    return (
      <div className="flex flex-col h-full items-center justify-center p-4">
        <Confetti isActive={showConfetti} onComplete={() => setShowConfetti(false)} />
        
        <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" className="mb-6" />
        
        <Card className="w-full max-w-md p-8 text-center bg-card">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            {percentage >= 80 ? 'Amazing!' : percentage >= 50 ? 'Good Job!' : 'Keep Trying!'}
          </h2>
          
          <div className="text-6xl font-bold text-primary mb-4">
            {finalScore}/{questions.length}
          </div>
          
          <p className="text-xl text-muted-foreground mb-6">
            You scored {percentage}%
          </p>
          
          <div className="flex flex-col gap-3">
            <Button onClick={onBack} size="lg">
              Back to Lessons
            </Button>
            <Button 
              variant="outline" 
              onClick={() => {
                setCurrentIndex(0);
                setSelectedAnswer(null);
                setIsAnswered(false);
                setScore(0);
                setQuizComplete(false);
                setExpression('encouraging');
              }}
            >
              Try Again
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <Confetti isActive={showConfetti} onComplete={() => setShowConfetti(false)} />
      
      {/* Header */}
      <div className="flex items-center gap-4 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="h-6 w-6" />
          <span className="sr-only">Back to lessons</span>
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          <p className="text-muted-foreground">
            Question {currentIndex + 1} of {questions.length}
          </p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-4 py-2">
        <Progress value={progress} className="h-3" />
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-4 overflow-auto">
        {/* Avatar */}
        <div className="lg:w-1/3 flex flex-col items-center">
          <MsMaya expression={expression} isSpeaking={isSpeaking} size="lg" />
        </div>

        {/* Question and answers */}
        <div className="lg:w-2/3 flex flex-col">
          <Card className="p-6 mb-6 bg-card">
            <button 
              onClick={readQuestion}
              disabled={isSpeaking}
              className="text-2xl font-semibold text-foreground text-left w-full hover:text-primary transition-colors"
            >
              {currentQuestion.question}
            </button>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 flex-1">
            {currentQuestion.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrect = index === currentQuestion.correctAnswer;
              const showResult = isAnswered;
              
              return (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  disabled={isAnswered}
                  className={cn(
                    'p-6 rounded-xl text-xl font-bold transition-all duration-200',
                    'flex items-center justify-center gap-3',
                    'focus:outline-none focus:ring-4 focus:ring-primary/50',
                    !showResult && 'hover:scale-105 active:scale-95',
                    !showResult && 'bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground',
                    showResult && isCorrect && 'bg-success text-success-foreground',
                    showResult && isSelected && !isCorrect && 'bg-destructive text-destructive-foreground',
                    showResult && !isSelected && !isCorrect && 'bg-muted text-muted-foreground opacity-50'
                  )}
                >
                  {showResult && isCorrect && <Check className="h-6 w-6" />}
                  {showResult && isSelected && !isCorrect && <X className="h-6 w-6" />}
                  {option}
                </button>
              );
            })}
          </div>

          {isAnswered && (
            <Button 
              onClick={handleNext} 
              size="lg" 
              className="mt-6"
            >
              {currentIndex < questions.length - 1 ? 'Next Question' : 'See Results'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

// Quiz data generators
export function generateAlphabetQuiz(): QuizQuestion[] {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  const words: Record<string, string> = {
    A: 'Apple', B: 'Ball', C: 'Cat', D: 'Dog', E: 'Elephant',
    F: 'Fish', G: 'Grapes', H: 'Hat', I: 'Ice cream', J: 'Juice',
    K: 'Kite', L: 'Lion', M: 'Moon', N: 'Nest', O: 'Orange',
    P: 'Penguin', Q: 'Queen', R: 'Rainbow', S: 'Sun', T: 'Tree',
    U: 'Umbrella', V: 'Violin', W: 'Watermelon', X: 'Xylophone', 
    Y: 'Yo-yo', Z: 'Zebra'
  };

  const shuffled = [...letters].sort(() => Math.random() - 0.5).slice(0, 5);
  
  return shuffled.map((letter, i) => {
    const otherLetters = letters.filter(l => l !== letter).sort(() => Math.random() - 0.5).slice(0, 3);
    const options = [letter, ...otherLetters].sort(() => Math.random() - 0.5);
    
    return {
      id: `alpha-${i}`,
      question: `Which letter makes the sound in "${words[letter]}"?`,
      options,
      correctAnswer: options.indexOf(letter),
      explanation: `${letter} is for ${words[letter]}!`,
    };
  });
}

export function generateNumbersQuiz(): QuizQuestion[] {
  const questions: QuizQuestion[] = [];
  
  // What comes next?
  for (let i = 0; i < 3; i++) {
    const start = Math.floor(Math.random() * 17) + 1;
    const answer = start + 1;
    const options = [answer, answer + 1, answer - 1, answer + 2]
      .filter(n => n > 0 && n <= 20)
      .slice(0, 4)
      .sort(() => Math.random() - 0.5);
    
    questions.push({
      id: `num-next-${i}`,
      question: `What number comes after ${start}?`,
      options: options.map(String),
      correctAnswer: options.indexOf(answer),
      explanation: `${start} plus 1 equals ${answer}!`,
    });
  }
  
  // How many?
  const counts = [3, 5, 7];
  counts.forEach((count, i) => {
    const options = [count, count + 1, count - 1, count + 2]
      .filter(n => n > 0)
      .slice(0, 4)
      .sort(() => Math.random() - 0.5);
    
    questions.push({
      id: `num-count-${i}`,
      question: `How many stars? ${'*'.repeat(count)}`,
      options: options.map(String),
      correctAnswer: options.indexOf(count),
      explanation: `There are ${count} stars!`,
    });
  });

  return questions.slice(0, 5);
}

export function generatePhonicsQuiz(): QuizQuestion[] {
  const sounds = ['at', 'an', 'ig', 'op', 'ug'];
  const wordPairs: Record<string, string[]> = {
    at: ['cat', 'hat', 'bat'],
    an: ['can', 'fan', 'man'],
    ig: ['pig', 'big', 'dig'],
    op: ['hop', 'top', 'pop'],
    ug: ['bug', 'hug', 'mug'],
  };

  return sounds.map((sound, i) => {
    const correctWord = wordPairs[sound][Math.floor(Math.random() * wordPairs[sound].length)];
    const wrongWords = Object.entries(wordPairs)
      .filter(([s]) => s !== sound)
      .map(([, words]) => words[0])
      .slice(0, 3);
    
    const options = [correctWord, ...wrongWords].sort(() => Math.random() - 0.5);
    
    return {
      id: `phonics-${i}`,
      question: `Which word has the "-${sound}" sound?`,
      options,
      correctAnswer: options.indexOf(correctWord),
      explanation: `${correctWord} has the "-${sound}" sound!`,
    };
  });
}
