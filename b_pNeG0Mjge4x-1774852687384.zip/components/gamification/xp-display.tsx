'use client';

import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Star, Flame } from 'lucide-react';

interface XPDisplayProps {
  xp: number;
  streak: number;
  showAnimation?: boolean;
  className?: string;
}

export function XPDisplay({ xp, streak, showAnimation = false, className }: XPDisplayProps) {
  const [animatedXP, setAnimatedXP] = useState(xp);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (showAnimation && xp > animatedXP) {
      setIsAnimating(true);
      const timer = setTimeout(() => {
        setAnimatedXP(xp);
        setIsAnimating(false);
      }, 500);
      return () => clearTimeout(timer);
    } else {
      setAnimatedXP(xp);
    }
  }, [xp, animatedXP, showAnimation]);

  return (
    <div className={cn('flex items-center gap-4', className)}>
      {/* XP Counter */}
      <div className={cn(
        'flex items-center gap-2 px-4 py-2 rounded-full bg-xp-gold/20 text-foreground',
        isAnimating && 'animate-bounce-in'
      )}>
        <Star className="h-5 w-5 text-xp-gold fill-xp-gold" />
        <span className="font-bold text-lg">{animatedXP}</span>
        <span className="text-sm text-muted-foreground">XP</span>
      </div>

      {/* Streak Counter */}
      {streak > 0 && (
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-streak-orange/20 text-foreground">
          <Flame className="h-5 w-5 text-streak-orange" />
          <span className="font-bold text-lg">{streak}</span>
          <span className="text-sm text-muted-foreground">day{streak !== 1 ? 's' : ''}</span>
        </div>
      )}
    </div>
  );
}
