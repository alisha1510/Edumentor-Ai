'use client';

import { Badge as BadgeType } from '@/lib/progress-store';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { Star, Trophy, Calculator, Flame, Lock } from 'lucide-react';

interface BadgeDisplayProps {
  badges: BadgeType[];
  className?: string;
}

const BADGE_ICONS: Record<string, React.ReactNode> = {
  star: <Star className="h-8 w-8" />,
  trophy: <Trophy className="h-8 w-8" />,
  calculator: <Calculator className="h-8 w-8" />,
  flame: <Flame className="h-8 w-8" />,
};

const BADGE_COLORS: Record<string, string> = {
  'first-lesson': 'from-yellow-400 to-amber-500',
  'alphabet-master': 'from-pink-400 to-rose-500',
  'number-wizard': 'from-blue-400 to-indigo-500',
  'streak-hero': 'from-orange-400 to-red-500',
};

export function BadgeDisplay({ badges, className }: BadgeDisplayProps) {
  return (
    <div className={cn('grid grid-cols-2 sm:grid-cols-4 gap-4', className)}>
      {badges.map((badge) => {
        const isUnlocked = !!badge.unlockedAt;
        const gradientClass = BADGE_COLORS[badge.id] || 'from-gray-400 to-gray-500';
        
        return (
          <Card
            key={badge.id}
            className={cn(
              'relative p-4 flex flex-col items-center text-center transition-all',
              isUnlocked 
                ? 'bg-card hover:scale-105' 
                : 'bg-muted/50 opacity-60'
            )}
          >
            {/* Badge icon */}
            <div className={cn(
              'w-16 h-16 rounded-full flex items-center justify-center mb-3',
              isUnlocked 
                ? `bg-gradient-to-br ${gradientClass} text-white shadow-lg`
                : 'bg-muted text-muted-foreground'
            )}>
              {isUnlocked ? (
                BADGE_ICONS[badge.icon] || <Star className="h-8 w-8" />
              ) : (
                <Lock className="h-8 w-8" />
              )}
            </div>

            {/* Badge info */}
            <h3 className={cn(
              'font-bold text-sm mb-1',
              isUnlocked ? 'text-foreground' : 'text-muted-foreground'
            )}>
              {badge.name}
            </h3>
            <p className="text-xs text-muted-foreground leading-tight">
              {badge.description}
            </p>

            {/* Unlocked indicator */}
            {isUnlocked && (
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-success rounded-full flex items-center justify-center">
                <svg className="w-4 h-4 text-success-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}
