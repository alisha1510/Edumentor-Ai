import {
  consumeStream,
  convertToModelMessages,
  streamText,
  UIMessage,
} from 'ai';

export const maxDuration = 30;

const SYSTEM_PROMPT = `You are Ms. Maya, a warm and friendly AI tutor for children ages 4-7. 

IMPORTANT RULES:
- Keep ALL responses under 60 words
- Use simple, age-appropriate language
- Be enthusiastic and encouraging
- Use positive reinforcement like "Great job!" and "You're doing amazing!"
- Ask simple follow-up questions to keep the child engaged
- If asked inappropriate topics, gently redirect to learning
- Focus on alphabet, numbers, phonics, and first words
- Never provide complex explanations
- Be patient and kind

You help children learn their ABCs, count numbers 1-20, understand phonics sounds, and read simple words. Make learning fun and interactive!`;

// Fallback responses when AI is not available
const FALLBACK_RESPONSES: Record<string, string[]> = {
  alphabet: [
    "The alphabet has 26 letters! A, B, C, D, E, F, G... Can you sing it with me?",
    "Great question about letters! A is for Apple, B is for Ball. What letter does your name start with?",
    "Let's learn letters together! After A comes B, then C. They make different sounds!",
  ],
  numbers: [
    "Numbers are so fun! Let's count: 1, 2, 3, 4, 5! Can you keep going?",
    "Great job with numbers! After 5 comes 6, then 7, 8, 9, 10! You're doing amazing!",
    "Let's count together! How many fingers do you have on one hand? That's right, 5!",
  ],
  phonics: [
    "The letter C makes a 'kuh' sound, like in Cat! Can you say 'Cat'?",
    "A says 'ah' like in Apple! E says 'eh' like in Elephant! What sound does your favorite letter make?",
    "Letters make special sounds! B says 'buh', D says 'duh'. Let's practice together!",
  ],
  default: [
    "That's a great question! Let's explore together. Would you like to learn about letters, numbers, or sounds today?",
    "I love your curiosity! We can learn about the alphabet, count numbers, or practice phonics. What sounds fun?",
    "You're doing wonderful! Let's keep learning. Should we practice letters, numbers, or read some words?",
    "Great job asking questions! Learning is so much fun. What would you like to explore - ABCs or 123s?",
  ],
};

function getFallbackResponse(userMessage: string): string {
  const message = userMessage.toLowerCase();
  
  if (message.includes('letter') || message.includes('abc') || message.includes('alphabet') || /\b[a-z]\b/.test(message)) {
    return FALLBACK_RESPONSES.alphabet[Math.floor(Math.random() * FALLBACK_RESPONSES.alphabet.length)];
  }
  
  if (message.includes('number') || message.includes('count') || /\d+/.test(message)) {
    return FALLBACK_RESPONSES.numbers[Math.floor(Math.random() * FALLBACK_RESPONSES.numbers.length)];
  }
  
  if (message.includes('sound') || message.includes('phonic') || message.includes('say')) {
    return FALLBACK_RESPONSES.phonics[Math.floor(Math.random() * FALLBACK_RESPONSES.phonics.length)];
  }
  
  return FALLBACK_RESPONSES.default[Math.floor(Math.random() * FALLBACK_RESPONSES.default.length)];
}

// Stream a fallback response character by character
function createFallbackStream(text: string): ReadableStream {
  const encoder = new TextEncoder();
  let index = 0;
  
  return new ReadableStream({
    async pull(controller) {
      if (index < text.length) {
        // Send text-delta chunk
        const chunk = {
          type: 'text-delta',
          delta: text[index],
        };
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(chunk)}\n\n`));
        index++;
        await new Promise(resolve => setTimeout(resolve, 20)); // Simulate typing
      } else {
        // Send finish chunk
        const finishChunk = {
          type: 'finish',
          finishReason: 'stop',
        };
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(finishChunk)}\n\n`));
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        controller.close();
      }
    },
  });
}

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();

  // Get the last user message for fallback
  const lastUserMessage = messages.filter(m => m.role === 'user').pop();
  const userText = lastUserMessage?.parts
    ?.filter((p): p is { type: 'text'; text: string } => p.type === 'text')
    .map(p => p.text)
    .join('') || '';

  try {
    const result = streamText({
      model: 'google/gemini-2.5-flash',
      system: SYSTEM_PROMPT,
      messages: await convertToModelMessages(messages),
      abortSignal: req.signal,
      maxOutputTokens: 150,
    });

    return result.toUIMessageStreamResponse({
      originalMessages: messages,
      consumeSseStream: consumeStream,
    });
  } catch (error) {
    // Use fallback responses when AI is unavailable
    console.log('[v0] AI unavailable, using fallback response');
    const fallbackText = getFallbackResponse(userText);
    
    return new Response(createFallbackStream(fallbackText), {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  }
}
