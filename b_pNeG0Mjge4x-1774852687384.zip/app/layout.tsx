import type { Metadata, Viewport } from 'next'
import { Nunito } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const nunito = Nunito({ 
  subsets: ["latin"],
  weight: ["400", "600", "700", "800"],
  variable: "--font-nunito"
});

export const metadata: Metadata = {
  title: 'EduMentor AI - Learn with Ms. Maya',
  description: 'An interactive AI tutoring platform for children ages 4-7. Learn alphabet, numbers, phonics, and first words with your friendly AI teacher Ms. Maya!',
  generator: 'v0.app',
  keywords: ['education', 'children', 'AI tutor', 'learning', 'alphabet', 'numbers', 'phonics'],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#8B5CF6',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${nunito.className} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
